import React from 'react'
import Loader from "@/components/Loader"
const Loading = () => {
  return (
  <Loader />
  )
}

export default Loading